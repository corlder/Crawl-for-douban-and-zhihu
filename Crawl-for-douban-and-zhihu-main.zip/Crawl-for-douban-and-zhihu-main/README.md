# Crawl-for-douban-and-zhihu
使用Scrapy框架爬取豆瓣和知乎里有关哪吒2的评论，其中豆瓣有短评和长评，如果你想使用该爬虫，可以下载后，在strat_url改成你想抓取的豆瓣电影的url，对于知乎，则只需要修改问题的id（可以通过查看问题的url获取）
